package br.usjt.ads.arqdes.model.service;

import java.io.IOException;
import java.util.ArrayList;

import org.springframework.stereotype.Service;

import br.usjt.ads.arqdes.model.dao.FilmeDAO;
import br.usjt.ads.arqdes.model.entity.Filme;

//Quarta tentativa de Commit --- Adicao de Anotacoes do Spring

@Service
public class FilmeService 
{
	private FilmeDAO dao;
	
	public FilmeService() 
	{
		dao = new FilmeDAO();
	}
	
	public Filme inserirFilme(Filme filme) throws IOException 
	{
		int id = dao.inserirFilme(filme);
		filme.setId(id);
		return filme;
	}
	
	public Filme buscarFilme(int id) throws IOException 
	{
		return dao.buscarFilme(id);
	}
	
	public ArrayList<Filme> listarFilmes(String chave) throws IOException 
	{
		return dao.listarFilmes(chave);
	}
	
	public ArrayList<Filme> listarFilmes() throws IOException 
	{
		return dao.buscarFilmes();
	}
	
	public Filme atualizarFilme(Filme filme) throws IOException 
	{
		int id = dao.atualizarFilme(filme);
		filme.setId(id);
		dao.atualizarFilme(filme);
		return filme;
	}

	public int deletarFilme(int id) throws IOException 
	{
		dao.deletarFilme(id);
		return id;
	}
	
	public ArrayList<Filme> ordenarGeneros() throws IOException 
	{
		return dao.ordenarGeneros();
	}
	
	public ArrayList<Filme> ordenarPopularidade() throws IOException 
	{
		return dao.ordenarPopularidade();
	}
	
	public ArrayList<Filme> ordenarData() throws IOException 
	{
		return dao.ordenarData();
	}

}