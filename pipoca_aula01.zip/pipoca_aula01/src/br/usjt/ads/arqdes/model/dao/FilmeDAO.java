package br.usjt.ads.arqdes.model.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import br.usjt.ads.arqdes.model.entity.Filme;
import br.usjt.ads.arqdes.model.entity.Genero;

// Quarta tentativa de Commit --- Adicao de Anotacoes do Spring  

@Repository
public class FilmeDAO 
{
	
	public int inserirFilme(Filme filme) throws IOException 
	{
		int id = -1;
		String sql = "insert into Filme (titulo, descricao, diretor, posterpath, "
				+ "popularidade, data_lancamento, id_genero) values (?,?,?,?,?,?,?)";
		
		try(Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pst = conn.prepareStatement(sql);)
		{
			
			pst.setString(1, filme.getTitulo());
			pst.setString(2, filme.getDescricao());
			pst.setString(3, filme.getDiretor());
			pst.setString(4, filme.getPosterPath());
			pst.setDouble(5, filme.getPopularidade());
			pst.setDate(6, new java.sql.Date(filme.getDataLancamento().getTime()));
			pst.setInt(7, filme.getGenero().getId());			
			pst.execute();
			
			//obter o id criado
			String query = "select LAST_INSERT_ID()";
			try(PreparedStatement pst1 = conn.prepareStatement(query);
				ResultSet rs = pst1.executeQuery();)
			{

				if (rs.next()) 
				{
					id = rs.getInt(1);
				}
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new IOException(e);
		}
		return id;
	}

	// Busca um filme pelo ID
	// Erick - RA:81523752
	// Aula01 Exercicios
	// Atualizacao - Aula 02: Agora retorna o id do item apagado.
	public Filme buscarFilme(int id) throws IOException
	{
		Filme filme = null;
		
		// Query Atualizada
		String sqlQuery = "select f.id, f.titulo, f.descricao, f.diretor, f.posterpath, f.popularidade, f.data_lancamento, f.id_genero, g.nome from filme f, genero g where f.id_genero = g.id and f.id like ?";
		
		try(Connection conn = ConnectionFactory.getConnection();
				PreparedStatement pst = conn.prepareStatement(sqlQuery);)
		{	
			pst.setInt(1, id);
			try(ResultSet rs = pst.executeQuery();)
			{
				// busca por genero
				Genero genero;
				while(rs.next()) 
				{
					filme = new Filme();
					filme.setId(rs.getInt("f.id"));
					filme.setTitulo(rs.getString("f.titulo"));
					filme.setDescricao(rs.getString("f.descricao"));
					filme.setDiretor(rs.getString("f.diretor"));
					filme.setPosterPath(rs.getString("f.posterpath"));
					filme.setPopularidade(rs.getDouble("f.popularidade"));
					filme.setDataLancamento(rs.getDate("f.data_lancamento"));
					genero = new Genero();
					genero.setId(rs.getInt("f.id_genero"));
					genero.setNome(rs.getString("g.nome"));
					filme.setGenero(genero);
				}
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new IOException(e);
		}
		
		return filme;
	}
	
	// Busca Filme por chave
	// Erick - RA: 81523752
	// Aula02
	public ArrayList<Filme> listarFilmes(String chave) throws IOException 
	{
		ArrayList<Filme> lista = new ArrayList<>();
		String sqlQuery = "select f.id, f.titulo, f.descricao, f.diretor, f.posterpath, "
				+ "f.popularidade, f.data_lancamento, f.id_genero, g.nome "
				+ "from filme f, genero g "
				+ "where f.id_genero = g.id and upper(f.titulo) like ?";
		try(Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pst = conn.prepareStatement(sqlQuery);)
		{
			
			pst.setString(1, "%" + chave.toUpperCase() + "%");
		
			try(ResultSet rs = pst.executeQuery();)
			{
			
				Filme filme;
				Genero genero;
				while(rs.next()) 
				{
					filme = new Filme();
					filme.setId(rs.getInt("f.id"));
					filme.setTitulo(rs.getString("f.titulo"));
					filme.setDescricao(rs.getString("f.descricao"));
					filme.setDiretor(rs.getString("f.diretor"));
					filme.setPosterPath(rs.getString("f.posterpath"));
					filme.setPopularidade(rs.getDouble("f.popularidade"));					
					filme.setDataLancamento(rs.getDate("f.data_lancamento"));
					genero = new Genero();
					genero.setId(rs.getInt("f.id_genero"));
					genero.setNome(rs.getString("g.nome"));
					filme.setGenero(genero);
					lista.add(filme);
				}
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new IOException(e);
		}
				
		return lista;
	}

	// Busca todos os filmes
	// Erick - RA: 81523752
	// Aula01 Exercicios
	public ArrayList<Filme> buscarFilmes() throws IOException
	{
		Filme filme;
		ArrayList<Filme> lista = new ArrayList<Filme>();
		
		//Query Atualizada
		String sqlQuery = "select f.id, f.titulo, f.descricao, f.diretor, f.posterpath, "
				+ "f.popularidade, f.data_lancamento, f.id_genero, g.nome "
				+ "from filme f, genero g "
				+ "where f.id_genero = g.id";
		
		try(Connection conn = ConnectionFactory.getConnection();
				PreparedStatement pst = conn.prepareStatement(sqlQuery);
				ResultSet rs = pst.executeQuery();)
		{
				
			Genero genero;
			while(rs.next()) 
			{
					filme = new Filme();
					filme.setId(rs.getInt("f.id"));
					filme.setTitulo(rs.getString("f.titulo"));
					filme.setDescricao(rs.getString("f.descricao"));
					filme.setDiretor(rs.getString("f.diretor"));
					filme.setPosterPath(rs.getString("f.posterpath"));
					filme.setPopularidade(rs.getDouble("f.popularidade"));	
					filme.setDataLancamento(rs.getDate("f.data_lancamento"));
					genero = new Genero();
					genero.setId(rs.getInt("f.id_genero"));
					genero.setNome(rs.getString("g.nome"));
					filme.setGenero(genero);
					lista.add(filme);
			}
	} 
	catch (SQLException e) 
	{
		e.printStackTrace();
		throw new IOException(e);
	}				
		return lista;
	}
	
	// Atualiza um filme
	// Erick - RA: 81523752
	// Aula01 Exercicios
	// Atualizacao - Aula 02: Agora retorna o id do item Atualizado para uma futura busca por id.
	public int atualizarFilme(Filme filme) throws IOException
	{
		int id = -1;
		String sqlQuery = "update Filme set titulo=?, descricao=?, diretor=?, posterpath=?, popularidade=?, data_lancamento=?, id_genero=? where id=?";
		
		try(Connection conn = ConnectionFactory.getConnection();
				PreparedStatement pst = conn.prepareStatement(sqlQuery))
		{
			pst.setString(1, filme.getTitulo());
			pst.setString(2, filme.getDescricao());
			pst.setString(3, filme.getDiretor());
			pst.setString(4, filme.getPosterPath());
			pst.setDouble(5, filme.getPopularidade());
			if (filme.getDataLancamento() != null) 
			{
				pst.setDate(6, new java.sql.Date(filme.getDataLancamento().getTime()));

			} 
			else 
			{
				pst.setDate(6, null);
			}
			pst.setInt(7, filme.getGenero().getId());
			pst.setInt(8, filme.getId());

			pst.execute();

			// obter o id do update
			String query = "select LAST_INSERT_ID()";
			try (PreparedStatement pst1 = conn.prepareStatement(query); ResultSet rs = pst1.executeQuery();) 
			{

				if (rs.next()) 
				{
					id = rs.getInt(1);
				}
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new IOException(e);
		}
		return id;
	}
	
	// Deleta um filme
	// Erick - RA: 81523752
	// Aula01 Exercicios
	// Atualizacao - Aula 02: Agora retorna o id do item apagado.
	public int deletarFilme(int id) throws IOException
	{
		String sqlQuery = "DELETE FROM filme WHERE id = ?";
		try(Connection conn = ConnectionFactory.getConnection();
				PreparedStatement pst = conn.prepareStatement(sqlQuery))
		{
			pst.setInt(1,id);
			pst.execute();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new IOException();	
		}
		return id;
	}
	
	
	// -------------- Implementacoes Aula 02 -----------------
	
	// Ordena filmes por genero
	public ArrayList<Filme> ordenarGeneros() throws IOException 
	{
		ArrayList<Filme> lista = new ArrayList<>();
		String sql = "select f.id, f.titulo, f.descricao, f.diretor, f.posterpath, "
				+ "f.popularidade, f.data_lancamento, f.id_genero, g.nome "
				+ "from filme f, genero g "
				+ "where f.id_genero = g.id order by g.nome";
		try(Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();)
		{
			
			Filme filme;
			Genero genero;
			while(rs.next()) 
			{
				filme = new Filme();
				filme.setId(rs.getInt("f.id"));
				filme.setTitulo(rs.getString("f.titulo"));
				filme.setDescricao(rs.getString("f.descricao"));
				filme.setDiretor(rs.getString("f.diretor"));
				filme.setPosterPath(rs.getString("f.posterpath"));
				filme.setPopularidade(rs.getDouble("f.popularidade"));	
				filme.setDataLancamento(rs.getDate("f.data_lancamento"));
				genero = new Genero();
				genero.setId(rs.getInt("f.id_genero"));
				genero.setNome(rs.getString("g.nome"));
				filme.setGenero(genero);
				lista.add(filme);
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new IOException(e);
		}				
		return lista;
	}
	
	// ordena filmes por popularidade
	public ArrayList<Filme> ordenarPopularidade() throws IOException 
	{
		ArrayList<Filme> lista = new ArrayList<>();
		String sql = "select f.id, f.titulo, f.descricao, f.diretor, f.posterpath, "
				+ "f.popularidade, f.data_lancamento, f.id_genero, g.nome "
				+ "from filme f, genero g "
				+ "where f.id_genero = g.id order by f.popularidade desc";
		try(Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();)
		{
			
			Filme filme;
			Genero genero;
			while(rs.next()) 
			{
				filme = new Filme();
				filme.setId(rs.getInt("f.id"));
				filme.setTitulo(rs.getString("f.titulo"));
				filme.setDescricao(rs.getString("f.descricao"));
				filme.setDiretor(rs.getString("f.diretor"));
				filme.setPosterPath(rs.getString("f.posterpath"));
				filme.setPopularidade(rs.getDouble("f.popularidade"));	
				filme.setDataLancamento(rs.getDate("f.data_lancamento"));
				genero = new Genero();
				genero.setId(rs.getInt("f.id_genero"));
				genero.setNome(rs.getString("g.nome"));
				filme.setGenero(genero);
				lista.add(filme);
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new IOException(e);
		}				
		return lista;
	}
	// Ordena Filmes por data
	public ArrayList<Filme> ordenarData() throws IOException 
	{
		ArrayList<Filme> lista = new ArrayList<>();
		String sql = "select f.id, f.titulo, f.descricao, f.diretor, f.posterpath, "
				+ "f.popularidade, f.data_lancamento, f.id_genero, g.nome "
				+ "from filme f, genero g "
				+ "where f.id_genero = g.id order by f.data_lancamento desc";
		try(Connection conn = ConnectionFactory.getConnection();
			PreparedStatement pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();)
		{
			
			Filme filme;
			Genero genero;
			while(rs.next())
			{
				filme = new Filme();
				filme.setId(rs.getInt("f.id"));
				filme.setTitulo(rs.getString("f.titulo"));
				filme.setDescricao(rs.getString("f.descricao"));
				filme.setDiretor(rs.getString("f.diretor"));
				filme.setPosterPath(rs.getString("f.posterpath"));
				filme.setPopularidade(rs.getDouble("f.popularidade"));	
				filme.setDataLancamento(rs.getDate("f.data_lancamento"));
				genero = new Genero();
				genero.setId(rs.getInt("f.id_genero"));
				genero.setNome(rs.getString("g.nome"));
				filme.setGenero(genero);
				lista.add(filme);
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new IOException(e);
		}				
		return lista;
	}


}
